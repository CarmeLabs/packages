## Data
This is a placeholder for the data directory.

By default the data directory won't be stored to GitHub. Instead, the alternative is to store the data directory in an Azure/Google/Amazon bucket. (Currently WIP).
