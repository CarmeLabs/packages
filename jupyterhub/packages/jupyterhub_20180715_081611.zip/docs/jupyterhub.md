
## Before you Begin. The '--dryrun' option and the '--yes' Option 
Do you want to run the commands or just see them?  
Below we have set the carme option `dryrun` so that commands are printed and not executed. 

If executing carme commands from the command line, by default the CMD command and will print the command and ask you to confirm before executing it. In Jupyter notebooks, this interactivity isn't possible. Instead, just add the --yes flag. 


```python
#To run for real, just set dryrun=''
#dryrun= '' to run or dryrun='--dryrun' to print. 
dryrun=''
yes = '--yes'
```

## Jupyterhub on Kubernetes

This notebook can be used to launch a standard instance of Jupyterhub which includes a proxy server, and an instance of Jupyterhub. 

This assumes you have a lauchfile in your working directory and have a Kubernetes cluster already loaded. 



### Print Jupyterhub Commmands
Optionally you can print the configuration and common commands for your desired cluster. You can use this as a reference and copy and paste into the terminal.


```python
!carme cmd jupyterhub list
```

    carme: [INFO] All cmd commands issued from project root directory to ensure relative path consistency.
    carme: [INFO] These commands are currently installed:
    #Start of Jupyterhub
    #install_ssl: "helm install --name=letsencrypt --namespace=kube-system stable/kube-lego --set config.LEGO_EMAIL={jup_email} --set config.LEGO_URL=https://acme-v01.api.letsencrypt.org/directory"
    init_jupyterhub: [init_jupyterhub0, init_jupyterhub1, init_jupyterhub2, init_jupyterhub3]
    init_jupyterhub0: "mkdir ./config/{jup_namespace}"
    init_jupyterhub1: "cp ./config/jupyterhub-starter/config.yaml ./config/{jup_namespace}/config.yaml"
    init_jupyterhub2: "openssl rand -hex 32 > ./config/{jup_namespace}/secret_token.txt"
    init_jupyterhub3: "sed -i '' s/secret_token/$(cat ./config/{jup_namespace}/secret_token.txt)/g\
      \ ./config/{jup_namespace}/config.yaml"
    show_config: "cat {jup_config}"
    clone_repo: "helm repo add jupyterhub {jup_helm_repo} && helm repo update"
    install_jupyterhub: "helm install jupyterhub/jupyterhub --version={jup_version} --name={jup_releasename}\
      \ --namespace={jup_namespace} -f ../apps/jupyterhub/config.yaml"
    upgrade_jupyterhub: "helm upgrade {jup_namespace} jupyterhub/jupyterhub --version={jup_version}\
      \ -f ../apps/jupyterhub/config.yaml"
    describe_jupyterhub: "kubectl --namespace={jup_namespace} get pod"
    get_ip: "kubectl --namespace={jup_namespace} get svc proxy-public"
    delete_namespace: "kubectl delete namespace {jup_namespace}"
    delete_jupyterhub: "helm delete {jup_releasename} --purge"
    #End of Jupyterhub


## Initialize Jupyterhub Configuration File
The following will initialize Jupyterhub configuration in the /config/<jupyterhub_namespace>/config.yaml


```python
#Clone the Jupyterhub repo.
!carme cmd jupyterhub init $dryrun $yes
```

    carme: [INFO] All cmd commands issued from project root directory to ensure relative path consistency.
    carme: [INFO] Executing command block init:
    carme: [INFO] Running the command: init0
    carme: [INFO] Template: mkdir ./config/{jup_namespace}
    carme: [INFO] Command: mkdir ./config/carmehub
    Executing init0:
     mkdir ./config/carmehub
    mkdir: ./config/carmehub: File exists
    carme: [INFO] Running the command: init1
    carme: [INFO] Template: cp ./config/jupyterhub-starter/{platform}.yaml ./config/{jup_namespace}/config.yaml
    carme: [INFO] Command: cp ./config/jupyterhub-starter/azure.yaml ./config/carmehub/config.yaml
    Executing init1:
     cp ./config/jupyterhub-starter/azure.yaml ./config/carmehub/config.yaml
    carme: [INFO] Running the command: init2
    carme: [INFO] Template: openssl rand -hex 32 > ./config/{jup_namespace}/secret_token.txt
    carme: [INFO] Command: openssl rand -hex 32 > ./config/carmehub/secret_token.txt
    Executing init2:
     openssl rand -hex 32 > ./config/carmehub/secret_token.txt
    carme: [INFO] Running the command: init3
    carme: [INFO] Template: sed -i '' s/secret_token/$(cat ./config/{jup_namespace}/secret_token.txt)/g ./config/{jup_namespace}/config.yaml
    carme: [INFO] Command: sed -i '' s/secret_token/$(cat ./config/carmehub/secret_token.txt)/g ./config/carmehub/config.yaml
    Executing init3:
     sed -i '' s/secret_token/$(cat ./config/carmehub/secret_token.txt)/g ./config/carmehub/config.yaml
    carme: [INFO] Running the command: init4
    carme: [INFO] Template: helm repo add jupyterhub https://jupyterhub.github.io/helm-chart/
    carme: [INFO] Command: helm repo add jupyterhub https://jupyterhub.github.io/helm-chart/
    Executing init4:
     helm repo add jupyterhub https://jupyterhub.github.io/helm-chart/
    "jupyterhub" has been added to your repositories
    carme: [INFO] Running the command: init5
    carme: [INFO] Template: helm repo update
    carme: [INFO] Command: helm repo update
    Executing init5:
     helm repo update
    Hang tight while we grab the latest from your chart repositories...
    ...Skip local chart repository
    ...Successfully got an update from the "jupyterhub" chart repository
    ...Successfully got an update from the "stable" chart repository
    Update Complete. ⎈ Happy Helming!⎈ 


## Install Jupyterhub


```python
#This will install the jupyterhub instance.
!carme cmd jupyterhub install $dryrun $yes

```

    carme: [INFO] All cmd commands issued from project root directory to ensure relative path consistency.
    carme: [INFO] Running the command: install
    carme: [INFO] Template: helm install jupyterhub/jupyterhub --version={version} --name={releasename} --namespace={namespace} -f ./config/{namespace}/config.yaml
    carme: [INFO] Command: helm install jupyterhub/jupyterhub --version=v0.6 --name=carmehub --namespace=carmehub -f ./config/carmehub/config.yaml
    Executing install:
     helm install jupyterhub/jupyterhub --version=v0.6 --name=carmehub --namespace=carmehub -f ./config/carmehub/config.yaml
    NAME:   carmehub
    LAST DEPLOYED: Sat Jul 14 15:55:27 2018
    NAMESPACE: carmehub
    STATUS: DEPLOYED
    
    RESOURCES:
    ==> v1/PersistentVolumeClaim
    NAME        STATUS   VOLUME   CAPACITY  ACCESS MODES  STORAGECLASS  AGE
    hub-db-dir  Pending  default  1s
    
    ==> v1/Service
    NAME          TYPE          CLUSTER-IP    EXTERNAL-IP  PORT(S)                     AGE
    hub           ClusterIP     10.0.154.99   <none>       8081/TCP                    1s
    proxy-api     ClusterIP     10.0.193.37   <none>       8001/TCP                    1s
    proxy-http    ClusterIP     10.0.121.63   <none>       8000/TCP                    1s
    proxy-public  LoadBalancer  10.0.216.127  <pending>    80:32531/TCP,443:32661/TCP  1s
    
    ==> v1beta1/Deployment
    NAME   DESIRED  CURRENT  UP-TO-DATE  AVAILABLE  AGE
    hub    1        1        1           0          1s
    proxy  1        1        1           0          1s
    
    ==> v1beta1/PodDisruptionBudget
    NAME   MIN AVAILABLE  MAX UNAVAILABLE  ALLOWED DISRUPTIONS  AGE
    hub    1              N/A              0                    1s
    proxy  1              N/A              0                    1s
    
    ==> v1/Pod(related)
    NAME                    READY  STATUS             RESTARTS  AGE
    hub-675f6bd679-xnb9x    0/1    Pending            0         1s
    proxy-68bfdbf96d-dsvtl  0/2    ContainerCreating  0         1s
    
    ==> v1/Secret
    NAME        TYPE    DATA  AGE
    hub-secret  Opaque  1     1s
    
    ==> v1/ConfigMap
    NAME                DATA  AGE
    hub-config          25    1s
    nginx-proxy-config  1     1s
    
    
    NOTES:
    Thank you for installing JupyterHub!
    
    Your release is named carmehub and installed into the namespace carmehub.
    
    You can find if the hub and proxy is ready by doing:
    
     kubectl --namespace=carmehub get pod
    
    and watching for both those pods to be in status 'Ready'.
    
    You can find the public IP of the JupyterHub by doing:
    
     kubectl --namespace=carmehub get svc proxy-public
    
    It might take a few minutes for it to appear!
    
    Note that this is still an alpha release! If you have questions, feel free to
      1. Come chat with us at https://gitter.im/jupyterhub/jupyterhub
      2. File issues at https://github.com/jupyterhub/zero-to-jupyterhub-k8s/issues
    



```python
#This will check on the status of Jupyterhub.
!carme cmd jupyterhub get_ip $dryrun $yes
```

    carme: [INFO] All cmd commands issued from project root directory to ensure relative path consistency.
    carme: [INFO] Running the command: get_ip
    carme: [INFO] Template: kubectl --namespace={namespace} get svc proxy-public --output=wide
    carme: [INFO] Command: kubectl --namespace=carmehub get svc proxy-public --output=wide
    Executing get_ip:
     kubectl --namespace=carmehub get svc proxy-public --output=wide
    NAME           TYPE           CLUSTER-IP     EXTERNAL-IP      PORT(S)                      AGE       SELECTOR
    proxy-public   LoadBalancer   10.0.216.127   40.113.237.199   80:32531/TCP,443:32661/TCP   6m        component=proxy,name=proxy,release=carmehub


## Update Authorization
When just starting out, the default configuration launches with no password.  While there is still a username and login screen.
```
!carme app jupyter jup_dummy_auth
!carme app jupyter jup_google_auth
!carme app jupyter jup_github_auth
```


```python
!carme app jupyter jup_dummy_auth

```


```python
!carme app jupyter jup_admin
```

### Update the Singleuser Container
This can allow you to utilize a different container. 



```python
#Upgrading Jupyterhub 
!carme cmd jupyterhub upgrade $dryrun $yes
```

    carme: [INFO] Running the command: upgrade_jupyterhub
    carme: [INFO] Template: helm upgrade {jup_namespace} jupyterhub/jupyterhub --version={jup_version} -f ../apps/jupyterhub/config.yaml
    carme: [INFO] Values: helm upgrade techfund2018v2 jupyterhub/jupyterhub --version=v0.6 -f ../apps/jupyterhub/config.yaml
    Executing upgrade_jupyterhub:
     helm upgrade techfund2018v2 jupyterhub/jupyterhub --version=v0.6 -f ../apps/jupyterhub/config.yaml
    Release "techfund2018v2" has been upgraded. Happy Helming!
    LAST DEPLOYED: Sat Apr 21 21:40:50 2018
    NAMESPACE: techfund2018v2
    STATUS: DEPLOYED
    
    RESOURCES:
    ==> v1beta1/Deployment
    NAME   DESIRED  CURRENT  UP-TO-DATE  AVAILABLE  AGE
    hub    1        1        1           0          2d
    proxy  1        1        1           1          2d
    
    ==> v1/Secret
    NAME        TYPE    DATA  AGE
    hub-secret  Opaque  1     2d
    
    ==> v1/ConfigMap
    NAME                DATA  AGE
    hub-config          31    2d
    nginx-proxy-config  1     2d
    
    ==> v1/PersistentVolumeClaim
    NAME        STATUS  VOLUME                                    CAPACITY  ACCESS MODES  STORAGECLASS  AGE
    hub-db-dir  Bound   pvc-7f5c1f1d-4388-11e8-99b9-42010a8e01e6  1Gi       RWO           standard      2d
    
    ==> v1/ServiceAccount
    NAME   SECRETS  AGE
    hub    1        2d
    proxy  1        2d
    
    ==> v1beta1/ClusterRole
    NAME                  AGE
    nginx-techfund2018v2  2d
    
    ==> v1beta1/ClusterRoleBinding
    NAME                  AGE
    nginx-techfund2018v2  2d
    
    ==> v1beta1/Role
    NAME       AGE
    hub        2d
    kube-lego  2d
    nginx      2d
    
    ==> v1beta1/PodDisruptionBudget
    NAME   MIN AVAILABLE  MAX UNAVAILABLE  ALLOWED DISRUPTIONS  AGE
    hub    1              N/A              0                    2d
    proxy  1              N/A              0                    2d
    
    ==> v1/Pod(related)
    NAME                  READY  STATUS             RESTARTS  AGE
    hub-549d95b5c9-6kq54  0/1    ContainerCreating  0         1s
    hub-676fc8846-7m89k   1/1    Terminating        0         33m
    proxy-94cb57d8-52pzk  3/3    Running            0         1d
    
    ==> v1beta1/RoleBinding
    NAME       AGE
    hub        2d
    kube-lego  2d
    nginx      2d
    
    ==> v1/Service
    NAME          TYPE          CLUSTER-IP     EXTERNAL-IP    PORT(S)                     AGE
    hub           ClusterIP     10.15.253.123  <none>         8081/TCP                    2d
    proxy-public  LoadBalancer  10.15.253.15   35.190.129.37  80:31988/TCP,443:31091/TCP  2d
    proxy-api     ClusterIP     10.15.255.150  <none>         8001/TCP                    2d
    proxy-http    ClusterIP     10.15.243.21   <none>         8000/TCP                    2d
    
    ==> v1beta1/Ingress
    NAME                 HOSTS                  ADDRESS        PORTS    AGE
    jupyterhub-internal  lab.analyticsdojo.com  35.196.141.94  80, 443  1d
    
    
    NOTES:
    Thank you for installing JupyterHub!
    
    Your release is named techfund2018v2 and installed into the namespace techfund2018v2.
    
    You can find if the hub and proxy is ready by doing:
    
     kubectl --namespace=techfund2018v2 get pod
    
    and watching for both those pods to be in status 'Ready'.
    
    You can find the public IP of the JupyterHub by doing:
    
     kubectl --namespace=techfund2018v2 get svc proxy-public
    
    It might take a few minutes for it to appear!
    
    Note that this is still an alpha release! If you have questions, feel free to
      1. Come chat with us at https://gitter.im/jupyterhub/jupyterhub
      2. File issues at https://github.com/jupyterhub/zero-to-jupyterhub-k8s/issues
    


## Cleanup the Installation
This will cleanup the installation, deleting the instance of Jupyterhub.


```python
#Upgrading Jupyterhub 
!carme cmd jupyterhub delete $dryrun $yes
```

    carme: [INFO] All cmd commands issued from project root directory to ensure relative path consistency.
    carme: [INFO] Executing command block delete:
    carme: [INFO] Running the command: delete0
    carme: [INFO] Template: helm delete {releasename} --purge
    carme: [INFO] Command: helm delete carmehub --purge
    Executing delete0:
     helm delete carmehub --purge
    Error: release: "carmehub" not found
    carme: [INFO] Running the command: delete1
    carme: [INFO] Template: kubectl delete namespace {namespace}
    carme: [INFO] Command: kubectl delete namespace carmehub
    Executing delete1:
     kubectl delete namespace carmehub
    namespace "carmehub" deleted

