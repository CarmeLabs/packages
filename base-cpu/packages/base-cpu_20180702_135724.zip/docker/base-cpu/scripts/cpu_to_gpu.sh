cp -R ../../../../carme-base-cpu/docker/carme-base-cpu ../../../../carme-base-gpu/docker/carme-base-gpu
rm -rf ../../jupyter-base-gpu/scripts
