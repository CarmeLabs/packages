## Carme Base notebooks

This base notebook is not meant to be used as a package directly.
